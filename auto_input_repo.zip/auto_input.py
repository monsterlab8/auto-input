# Auto Input program
# kode lengkap sudah ada sebelumnya

print('Jalankan auto_input.py atau gunakan versi EXE hasil build.')
